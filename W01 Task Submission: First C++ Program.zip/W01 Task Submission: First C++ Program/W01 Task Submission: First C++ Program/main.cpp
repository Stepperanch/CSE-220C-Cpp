//
//  main.cpp
//  W01 Task Submission: First C++ Program
//
//  Created by Nels Buhrley  on 3/7/25.
//

#include <iostream>
#include <iomanip>
#include <string>

void accountLoop(int selection, float& balance, bool& keepGoing) {
    float transactionValue;
    std::cout << "" << std::endl;
    if (selection == 0) {
        keepGoing = false;
        std::cout << "Thank You" << std::endl;
    }
    else if (selection == 1) {
        std::cout << "Your account has $ " << std::fixed << std::setprecision(2) << balance << std::endl;
    }
    else if (selection == 2) {
        std::cout << "How much would you like to deposite" << std::endl;
        if (!(std::cin >> transactionValue)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid Choice" << std::endl;
            accountLoop(2, balance, keepGoing);
            }
        balance += transactionValue;
        accountLoop(1, balance, keepGoing);
    }
    else if (selection == 3) {
        std::cout << "How much would you like to withdrawl" << std::endl;
        if (!(std::cin >> transactionValue)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid Choice" << std::endl;
            accountLoop(2, balance, keepGoing);
            }
        balance -= transactionValue;
        accountLoop(1, balance, keepGoing);
    }
    else {
        std::cout << "Invalid Choice" << std::endl;
    }
    std::cout << "" << std::endl;
}


int main(int argc, const char * argv[]) {
    // insert code here...
    bool keepGoing = true;
    int selection;
    float balance = 0;
    int accountID = 0;
    std::string userName;
    bool thereIsAError;
    std::cout << "Welcome to the Banking Interface" << std::endl;
    std::cout << "" << std::endl;
    do {
        std::cout << "What is the Uesrname?" << std::endl;
        std::getline(std::cin, userName);
        std::cout << "What is the Balance?" << std::endl;
        if (!(std::cin >> balance)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid Choice" << std::endl;
            thereIsAError = true;
            }
        else {
            thereIsAError = false;
        }
    } while (thereIsAError);
    
    std::cout << "" << std::endl;
    
    do {
        std::cout << "Select one of the folowing" << std::endl;
        std::cout << "1 - View Account Information" << std::endl;
        std::cout << "2 - Deposit" << std::endl;
        std::cout << "3 - Withdrawl" << std::endl;
        std::cout << "0 - End" << std::endl;
        
        if (!(std::cin >> selection)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            selection = 4;
            }
        if (selection == 1) {
            std::cout << "" << std::endl;
            std::cout << "Account ID: " << accountID << std::endl;
            std::cout << "Name: " << userName << std::endl;
        }
        accountLoop(selection, balance, keepGoing);
    }
    while(keepGoing);
    return 0;
}

